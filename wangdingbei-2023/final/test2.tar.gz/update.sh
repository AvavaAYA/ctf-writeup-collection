mv ./jdaughter-1 /home/ctf/jdaughter
chmod +x /home/ctf/jdaughter