mv ./pwn-3 /pwn/pwn
chmod +x /pwn/pwn