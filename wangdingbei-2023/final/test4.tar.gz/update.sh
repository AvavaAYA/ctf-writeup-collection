mv ./javap-httpserver.jar /web/java/javap-httpserver.jar
chmod +x /web/java/*
