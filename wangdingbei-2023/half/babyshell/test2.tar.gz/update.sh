#!/bin/sh

mv babyshell /home/ctf/babyshell
chmod +x /home/ctf/babyshell
