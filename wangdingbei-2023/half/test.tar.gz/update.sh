#!/bin/sh

mv server /home/ctf/server
chmod +x /home/ctf/server
